from django.apps import AppConfig


class HomesappConfig(AppConfig):
    name = 'homesapp'
